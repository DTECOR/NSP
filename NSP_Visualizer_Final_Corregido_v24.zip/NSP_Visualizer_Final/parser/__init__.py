# Inicialización del paquete parser
